function  [sSys,sCor,sRepFreq,sRepTemp] = DISC_PID_EXEMPLE
% Fichier d'exemple de param�trage de l'utilitaire PIDdiscSynth V7

% D�finition du Syst�me
Te = 0.01;      % P�riode d'�chantillonnage
B = 5 ;         % num�rateur de H(p)
A = [1 2 1] ;   % d�nominateur de H(p)
H = tf(B,A);    % fonction de transfert � temps continu du syst�me � contr�ler
sys = c2d(H,Te,'zoh'); % Calcul de la fonction de transfert � temps discret

%--------------------------------------------------------------------------
% Syst�me
sSys = struct(...
        'sys',     	sys,...	% Fonction de transfert du syst�me en 'z'
        'ARef',     10,...  % Amplitude de la consigne
        'APu',     	3,... 	% Amplitude de l'entr�e de perturbation de commande
        'APutau',   Te,...  % Constante de temps du 1er ordre de la perturbation
        'Nmax',     10 );   % Amplification max autoris�e du bruit de mesure

% Correcteur
sCor = struct(...
        'Te',       Te,...      % P�riode d'�chantillonnage
        'Gain',     3.5,...     % Gain proportionnel
        'Ki',       0.008,...   % Gain de l'int�grateur 
        'Int_on',   1,...       % Int�grateur : on=1, off=0
        'Kd',       22,...      % Gain du d�rivateur
        'a' ,       2,...       % Coeff. de filtrage du d�rivateur
        'Der_Ref',  1,...       % Derivation de la consigne : oui=1, non=0
        'Der_on',   1,...       % Application des gains P et D � la consigne : oui=1, non=0
        'Whf',      1,...       % Pulsation de coupure du filtre haute fr�quence
        'Whf_on',   0,...       % Filtre HF : on=1, off=0
        'AddNum',   [1],...     % Num�rateur correcteur additionnel (temps continu 's')
        'AddDen',   [0.1 1],... % D�nominateur correcteur additionnel (temps continu 's')
        'AddCont',  0,...       % Corr. Additionnel : on=1, off=0
        'Wref',     1,...       % Pulsation du Pr�filtre
        'FilOrder', 1,...       % Prefilter order : 1=1st order, 2=2nd order
        'Wref_on',  1,...       % Pr�filtre : on=1, off=0
        'Rmin',     0.001,...   % Valeur min pour les gains du correcteur (doit ^etre >0)
        'Rmax',     1000);      % Valeur max pour les gains du correcteur (doit ^etre >Rmin)

% Param�tres des R�ponse fr�quentielles
sRepFreq = struct(...
        'Wmin',     1e-3,...    % pulsation min (rad/s)
        'Wmax',     1e3,...     % pulsation max (rad/s)
        'Gdbmax',   60,...      % Gain max en dB
        'Gdbmin',  -40,...      % Gain min en dB
        'Pmax',     90,...      % Phase max en degr�s
        'Pmin',   -225 );       % Phase min en degr�s

% R�ponse temporelle
sRepTemp = struct(...
        'Tinit',    30,...      % Dur�e initiale de la simulation
        'Tmin',     0.1,...     % Dur�e minimale de la simulation
        'Tmax',     100,...     % Dur�e maximale de la simulation
        'Ymax',     1.2*sSys.ARef,...     % Valeur max affich�e pour Y
        'Ymin',    -0.2*sSys.ARef,...     % Valeur min affich�e pour Y
        'Yticks', [-0.2 -0.05 0 0.05 0.95 1 1.05 1.2]*sSys.ARef,... % lignes pointill�s
        'Umax',    8,...     % Valeur max affich�e pour U
        'Umin',    -4,...       % Valeur min affich�e pour U
        'Uticks', [ -4 -2 0 2 4 6 8] ); % lignes pointill�s
%--------------------------------------------------------------------------